<?php

define('ADMIN_NAME', 'ILEEADS ADMIN');
define('ADMIN_USERNAME', 'ILEE_ADMIN');
define('ADMIN_CHAT_ID', 1094274287);
define('SERVICE_NAME', 'PYTM FOX');
define('CHANNEL_ID', -1001471276454);
define('PAYOUT_GROUP_ID', -1001488871488);
define('BOT_USERNAME', 'Pytmfox_bot');
define('BOT_ID', '1494613529');

$dbusr = 'user';
$dbpas = 'pass';
$dbnam = 'db';

$token = 'TOKEN';

$botcreator = '1094274287';


